package com.mew.kyle.turnstile;

public class Output {
    private static String output;

    public static String getOutput() {
        return output;
    }

    public static void setOutput(String o) {
        output = o;
    }
}
